
 <div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/aw1.jpg" alt="Los Angeles" width="1100" height="500">
      <div class="carousel-caption">
        <h3 class="titulo2">Gana premios</h3>
        <p class="titulo2">Contesta nuestro cuestionario</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="img/aw2.jpg" alt="Chicago" width="1100" height="500">
      <div class="carousel-caption">
        <h3 class="titulo2">Premios</h3>
        <p class="titulo2">Thank you, Chicago!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="img/aw3.jpg" alt="New York" width="1100" height="500">
      <div class="carousel-caption">
        <h3 class="titulo2">New York</h3>
        <p class="titulo2">We love the Big Apple!</p>
      </div>   
    </div>
  </div>
  
</div>

 
   

   
   
   
<form action="" onsubmit="return false" id="fondillo2">
    <ul style="list-style: none;" ng-repeat="x in Preguntas">
        <li>
            <h3 id="{{x.user}}" class="titulo">{{x.pregunta}}</h3>
        </li>
        <li>
            <div class="form-check" ng-repeat="y in x.respuestas">
                <input class="form-check-input" ng-model="x.respuestaUsuario" value="{{y.id}}" type="radio" name="pregunta {{x.id}}" id="defaultCheck1" required>
                <label class="form-check-label" for="defaultCheck1" style="color: white;">
                    {{y.text}}
                </label>
            </div>
        </li>
    </ul>
    <h5 class="titulo">Respuestas correctas: <span style="color: rgba(73, 250, 66, 0.74);">{{contadorC}}</span></h5>
    <h5 class="titulo">Respuestas incorrectas: <span style="color: rgba(253, 52, 52, 0.76);">{{contadorM}}</span></h5>
    <h4 class="titulo">Calificacion: <span style="color: rgba(76, 166, 255, 0.98);"> {{calificacion | number:1}}</span></h4>
    <br><br>
    <div class="form-group">
    <label for="exampleInputEmail1" class="titulo">Correo Electronico</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Correo Electronico">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
   
    <button ng-click="validar()" type="submit" class="btn btn-light">Enviar</button>
</form>
