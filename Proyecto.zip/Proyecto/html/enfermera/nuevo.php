<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Nuevo Paciente</title>
    <link rel="stylesheet" href="../../vendor/bootstrap/css/bootstrap.min.css">
    <style>
        .centro {
            text-align: center;
        }

        @media only screen and (max-width: 991px) {
            .conta {
                display: none;
            }
        }

    </style>
</head>

<body class="container">
    <div class="row">
        <div class="col-md">
            <form method="post" action="ingreso.php" enctype="multipart/form-data">
                <div class="form-group"> <br>
                    <h1 class="centro">Ingrese Datos del Usuario</h1><br>
                    <label for="exampleInputEmail1">Nombre completo</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nombre completo" name="nombre" required>

                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Dirección</label>
                    <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Dirección" name="direccion" required>
                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">Telefono</label>
                    <input type="text" class="form-control" id="exampleInputPassword1" placeholder="Telefono" name="telefono" required>
                </div>

                <div class="form-group">
                    <label for="exampleInputPassword1">Correo Electronico</label>
                    <input type="email" class="form-control" id="exampleInputPassword1" placeholder="Correo Electronico" name="correo" required>
                </div>
                <label for="exampleInputPassword1">Fotografía</label>
                <div class="custom-file">

                    <input type="file" name="imagen" id="file">
                </div><br><br>

                <button type="submit" class="btn btn-primary">Ingresar Paciente</button>
            </form>
        </div>
        <div class="col-lg-4">
            <div class="conta">
                <br><br>
                <img src="../../img/Emer.jpg" alt="Snow" style="width:80%;"><br>
                <small style="color:red; padding:10px;">Recuerda llamar al 911 en caso de emergencia.</small>
            </div>
        </div>
    </div>
    <script>
var uploadField = document.getElementById("file");

uploadField.onchange = function() {
    if(this.files[0].size > 1000000){
       alert("Imagen muy grande, procure que sea menor a 1 MB");
       this.value = "";
    };
};
</script>
</body>

</html>
