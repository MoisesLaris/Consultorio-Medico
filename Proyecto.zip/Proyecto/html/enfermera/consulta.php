<br><br><br><br>

<?php
session_start();
if($_SESSION['id']){ ?>


<?php
       
         include("../conexion.php");
    $con=conectar();

       
        $consulta = 'SELECT * FROM Paciente';
        $resultado = mysqli_query( $con, $consulta ) or die ( "Algo ha ido mal en la consulta a la base de datos");

         while ($columna = mysqli_fetch_array( $resultado ))
        {
            if($columna['idPaciente']==$_SESSION['id']){
                $id=$_SESSION['id'];
                $nombre=$columna['nombre'];
                $direccion=$columna['direccion'];
                $telefono=$columna['telefono'];
                $correo=$columna['correo'];
                $imagen=$columna['imagen'];
            }
        }
        
        header("Content-type: image/jpeg"); 
        
        ?>
<div style="padding:20px;">
   <div class="row">
    <div class="col-6">
       <h2>Informacion del paciente</h2>
        <div class="card" style="width: 25rem; ">
            <img class="card-img-top" src="data:image/jpeg;base64,<?php echo base64_encode($imagen);?>" alt="Card image cap" width="100%;" height="auto";>
            <div class="card-body">
                <h5 class="card-title"><?php echo $nombre?></h5>
                <p class="card-text">Id: <?php echo $id?>
                <br>Dirección: <?php echo $direccion?>
                <br>Telefono: <?php echo $telefono?>
                <br>Correo: <?php echo $correo?></p>
                <a href="html/enfermera/cerrar.php" class="btn btn-info">Cambiar Paciente</a>
            </div>
        </div>

    
    
    </div><!--Ingresar datos que se llenaran en expediente -->
    <div class="col-md" style="background-color:#f0f0f0;">
       <h2 style="padding:10px;">Ingrese signos vitales</h2>
        <form action="html/enfermera/exp.php" method="post">
        <div class="form-group">
            <label for="exampleInputEmail1">Peso en kg</label>
            <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Peso" name="peso" required >
            <label for="exampleInputEmail1">Talla en cm</label>
            <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Talla" name="talla" required>
            <label for="exampleInputEmail1">Estatura en cm</label>
            <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Estatura" name="estatura" required>
            <label for="exampleInputEmail1">Temperatura Cº:</label>
            <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Temperatura" name="temperatura" required>
            <label for="exampleInputEmail1">Presión arterial:</label>
            <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Presion" name="presion" required>
            <label for="exampleInputEmail1">Pulso</label>
            <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Pulso" name="pulso" required>
            <label for="exampleInputEmail1">Alergias</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Alergias" name="alergias" required>
            <label for="exampleInputEmail1">Nota de estudios recientes</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Nota" name="nota" required>
            
            
        </div>
        <button type="submit" class="btn btn-success">Enviar y generar video-llamada</button><br><br>
       
    </form>
    </div>
    
    
    
    </div>
</div>



<?php }else{  ?>

<div class="container">
    <h3 id="fondo">Para iniciar consulta identifique al paciente</h3>
    <form action="html/enfermera/id.php" method="post">
        <div class="form-group">
            <label for="exampleInputEmail1">ID Paciente:</label>
            <input type="number" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Ingrese ID" name="identificacion">
            <small id="emailHelp" class="form-text text-muted">En caso de no saberlo indique a la enfermera para iniciar busqueda en la base de datos.</small>
            <small><?php echo $_GET['error']; ?></small>
        </div>
        <button type="submit" class="btn btn-success">Enviar</button>
        <a href="html/enfermera/nuevo.php" class="btn btn-info" style="color:white;">Registrar paciente </a>
    </form><br><br>


</div>
<?php } ?>
