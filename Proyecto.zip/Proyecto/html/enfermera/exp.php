<?php
    session_start();
    include("../conexion.php");
    $con=conectar();
if($_POST['peso']){
$peso=$_POST['peso'];
$talla=$_POST['talla'];
$estatura=$_POST['estatura'];
$temperatura=$_POST['temperatura'];
$presion=$_POST['presion'];
$pulso=$_POST['pulso'];
$alergias=$_POST['alergias'];
$nota=$_POST['alergias'];
$id_paciente=$_SESSION['id'];
$id_enfermera=$_SESSION['ide'];
    

$resultado=mysqli_query($con,"SELECT COUNT(*) idExpediente FROM Expediente");
            $numero = mysqli_fetch_assoc($resultado);
            $num=$numero['idExpediente']+1;
            $insertar="INSERT INTO Expediente (idExpediente, peso, talla, estatura, temperatura, presion_arterial, pulso, Enfermera_idEnfermera, Doctor_idDoctor, Paciente_idPaciente, Receta_idReceta, alergias, nota_medica, estudios, receta) VALUES ('$num', '$peso', '$talla', '$estatura', '$temperatura','$presion','$pulso','$id_enfermera','1','$id_paciente','0','$alergias','1','$nota','Nada aun');";
            
            $insertar=mysqli_query($con,$insertar);
    //No hay archivo

                        
}
header('Location: https://3b851050.ngrok.io/#init'); //Direccion del videochat

exit();

?>
