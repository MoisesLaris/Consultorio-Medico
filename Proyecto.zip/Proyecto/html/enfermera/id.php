<?php
    session_start();
    include("../conexion.php");
    $con=conectar();

        $identificacion=$_POST["identificacion"];
        
        //que busque en la base de datos de la enfermera y del doctor para poder verificar sie s uno u oro con el correo y la contraseña
        
        $consulta = 'SELECT * FROM Paciente';
        $resultado = mysqli_query( $con, $consulta ) or die ( "Algo ha ido mal en la consulta a la base de datos");

         while ($columna = mysqli_fetch_array( $resultado ))
        {
             $id=$columna['idPaciente'];
             if(strcasecmp($id, $identificacion) == 0){
                 $_SESSION['id']=$id;
                 header('Location: ../../index.php#!consulta');
                 exit();
             }
        }
        $error='id no identificado';
        header("Location: ../../index.php#!consulta?error=$error");


?>