<?php
    session_start();
    include("../conexion.php");
    $con=conectar();
if($_POST['nombre']){
$nombre=$_POST['nombre'];
$correo=$_POST['correo'];
$direccion=$_POST['direccion'];
$telefono=$_POST['telefono'];
$checar = getimagesize($_FILES["imagen"]["tmp_name"]);
if($checar !== false){
    $imagen=$_FILES['imagen']['tmp_name'];
    $contenido=addslashes(file_get_contents($imagen));
    
}
$resultado=mysqli_query($con,"SELECT COUNT(*) nombre FROM Paciente");
            $numero = mysqli_fetch_assoc($resultado);
            $num=$numero['nombre']+1;
            $insertar="INSERT INTO Paciente (idPaciente, nombre, direccion, telefono, correo, imagen) VALUES ('$num', '$nombre', '$direccion', '$telefono', '$correo','$contenido');";
            
            $insertar=mysqli_query($con,$insertar);
    //No hay archivo

            $_SESSION['id']=$num;
            
}
header("Location: /Proyecto/#!consulta");
            exit();
?>
