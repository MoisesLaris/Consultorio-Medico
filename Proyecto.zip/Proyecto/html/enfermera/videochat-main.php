<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Video chat</title>
    <link rel="stylesheet" href="../../vendor/bootstrap/css/bootstrap.min.css">
</head>
<body>
    <body class="container">
    <div class="row">
        <div class="col">
            <div class="embed-responsive embed-responsive-16by9">
                <iframe class="embed-responsive-item" src="https://9d68f551.ngrok.io/#init" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</body>
</body>
</html>