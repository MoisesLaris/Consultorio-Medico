<?php
  session_start();
    include("../conexion.php");
    $con=conectar();
  if($_SESSION["bin"]==0){
        $consulta = 'SELECT * FROM Doctor';
        $resultado = mysqli_query( $con, $consulta ) or die ( "Algo ha ido mal en la consulta a la base de datos");

         while ($columna = mysqli_fetch_array( $resultado ))
        {
             $correo2=$columna['correo'];
             if(strcasecmp($_SESSION['correo'], $correo2) == 0){
                 mysqli_query($con,"UPDATE Doctor SET status = '0' WHERE correo='$correo2'");
                 unset($_SESSION["correo"]);
             }
        }
      
      
  }else{}

  unset($_SESSION["nombre"]);
  unset($_SESSION["bin"]);
  unset($_SESSION["id"]);
  unset($_SESSION["ide"]);
  session_destroy();
  header("Location: ../../index.php");
  exit();
?>