
   <?php
    session_start();
    include("../conexion.php");
    $con=conectar();

        $correo=$_POST["correo"];
        $password=$_POST["contraseña"];
        //que busque en la base de datos de la enfermera y del doctor para poder verificar sie s uno u oro con el correo y la contraseña
        
        $consulta = 'SELECT * FROM Doctor';
        $resultado = mysqli_query( $con, $consulta ) or die ( "Algo ha ido mal en la consulta a la base de datos");
        $num=0;
         while ($columna = mysqli_fetch_array( $resultado ))
        {       
             $num++;
             $correo2=$columna['correo'];
             $password2=$columna['password'];
             $nombre=$columna['nombre'];
             if((strcasecmp($correo, $correo2) == 0)and(strcasecmp($password, $password2) == 0 )){
                 $_SESSION['nombre']=$nombre;
                 $_SESSION['correo']=$correo;
                 $_SESSION['bin']=0;
                 $_SESSION['ide']=$num;
                 mysqli_query($con,"UPDATE Doctor SET status = '1' WHERE correo='".$correo."'");
                 header('Location: ../../index.php');
                exit();
             }
        }

        $consulta = 'SELECT * FROM Enfermera';
        $resultado = mysqli_query( $con, $consulta ) or die ( "Algo ha ido mal en la consulta a la base de datos");
        $num=0;
         while ($columna = mysqli_fetch_array( $resultado ))
        {
             $num++;
             $correo2=$columna['correo'];
             $password2=$columna['password'];
             $nombre=$columna['nombre'];
             if((strcasecmp($correo, $correo2) == 0)and(strcasecmp($password, $password2) == 0 )){
                 $_SESSION['nombre']=$nombre;
                 $_SESSION['bin']=1;
                 $_SESSION['ide']=$num;
                 header('Location: ../../index.php');
                exit();
             }
        }
        
        $mensaje="Error en contraseña o correo, identifiquese correctamente";
        header("Location: ../log.php?error=$mensaje");
        exit();

?>