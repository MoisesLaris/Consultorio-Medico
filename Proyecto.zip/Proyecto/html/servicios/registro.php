<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Log in</title>
    <link rel="stylesheet" href="../css/login.css">
    <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div id="cuerpo">

        <form action="servicios/registrosesion.php" method="post">
            <div class="imgcontainer">
                <img src="../img/usuario.png" alt="Avatar" class="avatar">
            </div>

            <div class="container">
                <label for="uname"><b>Seleccione una opción</b></label><br><br>
                <input type="radio" name="opcion" value="0"> Doctor / Doctora<br>
                <input type="radio" name="opcion" value="1"> Enfermero / Enfermera <br> <br>
                <label for="uname"><b>Nombre</b></label>
                <input type="text" placeholder="Nombre " name="nombre" required>
                <label for="psw"><b>Correo Electronico</b></label>
                <input type="text" placeholder="Correo electronico" name="correo" required>
                <label for="psw"><b>Contraseña</b></label>
                <input type="password" placeholder="Contraseña" name="contraseña" required>
                <label for="psw"><b>Ingrese contraseña de nuevo</b></label>
                <input type="password" placeholder="Contraseña" name="contraseña2" required>
                <label for="psw" style="color:red; background-color:rgba(255, 0, 0, 0.1);"><b><?php echo $_GET['error']; ?></b></label><br>
                <label for="psw"><b>Numero telefonico</b></label>
                <input type="text" placeholder="Telefono" name="telefono" required>
                
                
                
                <button type="submit">Registrarse</button>
                <label>
                    <input type="checkbox" checked="checked" name="remember"> Remember me
                </label>
            </div>

           
        </form>

    </div>

</body>

</html>
