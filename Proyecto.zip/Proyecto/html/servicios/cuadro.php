<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
    <link rel="stylesheet" href="../../vendor/bootstrap/css/bootstrap.min.css">
</head>

<body>
    <?php
    session_start();
        if(isset($_SESSION['codigo']) and isset($_POST['c'])){
            $code=$_SESSION['codigo'];
            $cod=$_POST['c'];
            if($code==$cod){
                //Hace lo de la base de datos y salimos al index
                header("Location: registrosesion.php");
            }else{
                $error="El codigo de verificación es incorrecto, busque nuestro correo en su caperta de spam";
                header("Location: cuadro.php?error=$error");
                echo 'nada';
            }
        }else if(isset($_GET['can'])){
            unset($_SESSION["opcion"]);
            unset($_SESSION["correo"]);
            unset($_SESSION["pass"]);
            unset($_SESSION["telefono"]);
            unset($_SESSION["nombre"]);
            unset($_SESSION["codigo"]);
            
            header('Location: ../../index.php');
            exit();
        }else{
            
        }
    ?>
   
    <div class="container">
        <form method="post" action="cuadro.php" >
            <div class="form-group">
                <label for="exampleInputEmail1" class="mb-0">Ingrese codigo de verificación</label>
                <input type="number" class="form-control" name="c" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Código">
                <small style="color:red;"><?php echo $_GET['error']; ?></small>
            </div>
            <button type="submit" class="btn btn-primary">Enviar</button> 
            <a href="cuadro.php?can=cancelar" class="btn btn-danger" >Cancelar</a>
        </form>
            


    </div>
</body>

</html>
