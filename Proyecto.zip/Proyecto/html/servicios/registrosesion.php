<?php
    session_start();
    include("../conexion.php");
    $con=conectar();
      
        $opcion=$_SESSION["opcion"];
        $nombre=$_SESSION["nombre"];
        $correo=$_SESSION["correo"];
        $password=$_SESSION["pass"];
        $telefono=$_SESSION["telefono"];
        
        
        if(strcmp($opcion,'0')==0){
            $resultado=mysqli_query($con,"SELECT COUNT(*) nombre FROM Doctor");
            $numero = mysqli_fetch_assoc($resultado);
            $num=$numero['nombre']+1;
            $insertar="INSERT INTO Doctor (idDoctor, nombre, correo, telefono, password, status) VALUES ('$num', '$nombre', '$correo', '$telefono', '$password', '0');";
            
            mysqli_query($con,$insertar);
            $_SESSION['nombre']=$nombre;
            $_SESSION['bin']=0;
            $_SESSION['ide']=$num;
                 mysqli_query($con,"UPDATE Doctor SET status = '1' WHERE correo='$correo'");
                unset($_SESSION["opcion"]);
                unset($_SESSION["pass"]);
                unset($_SESSION["telefono"]);

                 header('Location: ../../index.php');
                exit();
        
        }else if(strcmp($opcion,'1')==0){
            $resultado=mysqli_query($con,"SELECT COUNT(*) nombre FROM Enfermera");
            $numero = mysqli_fetch_assoc($resultado);
            $num=$numero['nombre']+1;
            
            $insertar="INSERT INTO Enfermera (idEnfermera, nombre, correo, password, telefono) VALUES ('$num', '$nombre', '$correo', '$password', '$telefono');"; 
            mysqli_query($con,$insertar);
            $_SESSION['ide']=$num;
            $_SESSION['nombre']=$nombre;
            $_SESSION['bin']=1;
                unset($_SESSION["opcion"]);
                unset($_SESSION["pass"]);
                unset($_SESSION["telefono"]);
            

                 header('Location: ../../index.php');
            exit();
        }
        else{
            header('Location: ../../index.php');
            exit();
        }
            

        
?>
