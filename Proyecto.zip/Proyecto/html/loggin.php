<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>login/signup form animation</title>


    <link rel="stylesheet" href="../css/style.css">


</head>

<body>

    <div class="form-structor">
        <div class="signup">
            <h2 class="form-title" id="signup">Inicia Session</h2>
            <div class="form-holder">
                <form action="servicios/iniciosesion.php" method="post" name="f1">
                    <input type="email" class="input" name="correo" placeholder="Correo Electronico" />
                    <input type="password" name="contraseña" class="input" placeholder="Contraseña" />

                </form>

            </div>
            <small for="psw" style="color:white;"><b><?php echo $_GET['error']; ?></b></small>
            <button class="submit-btn" onclick="f1.submit()">Inicia Session</button>

        </div>
        <div class="login slide-up">
            <div class="center">
                <h2 class="form-title" id="login">Registrate</h2>
                <div class="form-holder">
                    <form action="servicios/registrosesion.php" name="f2" method="post">
                        <input type="text" class="input" name="nombre" placeholder="Nombre" required/>
                        <input type="email" class="input" name="correo" placeholder="Correo Electronico" required />
                        <input type="password" class="input" placeholder="Contraseña" name="contraseña" required />
                        <input type="password" class="input" placeholder="Confirmar contraseña" name="contraseña2" required />
                        <input type="text" class="input" name="telefono" placeholder="Telefono" required>
                        <input type="radio" name="opcion" value="0"> <small>Doctor / Doctora</small><br>
                        <input type="radio" name="opcion" value="1"> <small>Enfermero / Enfermera</small>
                    </form>
                </div>
                <button class="submit-btn" onclick="f2.submit()">Registrate</button>
            </div>
        </div>
    </div>



    <script src="../css/index.js"></script>




</body>

</html>
