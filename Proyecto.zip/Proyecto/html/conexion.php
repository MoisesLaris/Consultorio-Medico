<?php

function conectar(){
        $usuario = "root";
        $contrasena = "mysql";  // en mi caso tengo contraseña pero en casa caso introducidla aquí.
        $servidor = "localhost";
        $basededatos = "mydb";
    
        $conexion = mysqli_connect( $servidor, $usuario, "3119402" ) or die ("No se ha podido conectar al servidor de Base de datos");
        mysqli_select_db($conexion , $basededatos ) or die ( "Upps! Pues va a ser que no se ha podido conectar a la base de datos" );
        
        return $conexion;
}

?>
