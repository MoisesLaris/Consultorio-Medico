<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Informacion personal</title>
    <link rel="stylesheet" href="../../vendor/bootstrap/css/bootstrap.min.css">
</head>
<body>
 

<?php
session_start();
 ?>


<?php
       
         include("../conexion.php");
    $con=conectar();

       
        $consulta = 'SELECT * FROM Paciente';
        $resultado = mysqli_query( $con, $consulta ) or die ( "Algo ha ido mal en la consulta a la base de datos");

         while ($columna = mysqli_fetch_array( $resultado ))
        {
            if($columna['idPaciente']==$_GET['pac']){
                $id=$_GET['pac'];
                $nombre=$columna['nombre'];
                $direccion=$columna['direccion'];
                $telefono=$columna['telefono'];
                $correo=$columna['correo'];
                $imagen=$columna['imagen'];
            }
        }
        
        
        ?>
<div style="padding:20px;">
         <h2 style="background-color:rgba(0, 0, 0, 0.34); padding:8px; border-radius: 10px;">Informacion del paciente</h2><br>

   <div class="row">
  
        <div class="card" style="width: 50%; ">
            <img class="card-img-top" src="data:image/jpeg;base64,<?php echo base64_encode($imagen);?>" alt="Card image cap" width="50%;" height="auto";>
            <div class="card-body">
                <h5 class="card-title"><?php echo $nombre?></h5>
                <p class="card-text">Id: <?php echo $id?>
                <br>Dirección: <?php echo $direccion?>
                <br>Telefono: <?php echo $telefono?>
                <br>Correo: <?php echo $correo?></p>
                <a href="javascript:window.history.go(-1);" class="btn btn-primary">Regresar</a>
            </div>
        </div>
    </div>
    </div>

</body>
</html>