<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>información</title>
    <link rel="stylesheet" href="../../vendor/bootstrap/css/bootstrap.min.css">
</head>
<body>
   <br><br><br>
    <br><div class="container">
    <div class="row">
        <?php
    session_start();
    include("../conexion.php");
    $con=conectar();

        $identificacion=$_POST["identificacion"];
        
        //que busque en la base de datos de la enfermera y del doctor para poder verificar sie s uno u oro con el correo y la contraseña
        
        $consulta = 'SELECT * FROM Paciente';
        $resultado = mysqli_query( $con, $consulta ) or die ( "Algo ha ido mal en la consulta a la base de datos");
        
         while ($columna = mysqli_fetch_array( $resultado ))
        {
             
             $id=$columna['idPaciente'];
             $nombre=$columna['nombre'];
             $direccion=$columna['direccion'];
             $telefono=$columna['telefono'];
             $correo=$columna['correo'];
             
                 
             ?>
        <div class="card" style="width: 90%; ">
            <div class="card-body">
                <h5 class="card-title" style="background-color:rgba(67, 137, 232, 0.78); padding:10px; border-radius:5px;" >Id Paciente:  <?php echo $id?></h5>
                <p class="card-text">
                       Nombre: <?php echo $nombre?>
                    <br>Direccion: <?php echo $direccion?>
                    <br>Telefono: <?php echo $telefono?>
                    <br>Correo: <?php echo $correo?>
                    
                    </p>
                    
            </div>
        </div>
        <?php

        

        }



        ?>
        
                    
                    
    </div>
    <br><br>

</div><br> <br>




</body>
</html>