<br><br><br><br><div class="container">
    <div class="row">
        <?php
    session_start();
    include("../conexion.php");
    $con=conectar();

        $identificacion=$_POST["identificacion"];
        
        //que busque en la base de datos de la enfermera y del doctor para poder verificar sie s uno u oro con el correo y la contraseña
        
        $consulta = 'SELECT * FROM Expediente';
        $resultado = mysqli_query( $con, $consulta ) or die ( "Algo ha ido mal en la consulta a la base de datos");

         while ($columna = mysqli_fetch_array( $resultado ))
        {
             
             $id=$columna['idExpediente'];
             $peso=$columna['peso'];
             $talla=$columna['talla'];
             $estatura=$columna['estatura'];
             $temperatura=$columna['temperatura'];
             $alergias=$columna['alergias'];
             $ide=$columna['Enfermera_idEnfermera'];
             $idd=$columna['Doctor_idDoctor'];
             $idp=$columna['Paciente_idPaciente'];
             
             
             ?>
        <div class="card" style="width: 90%; ">
            <div class="card-body">
                <h5 class="card-title" style="background-color:rgba(0, 0, 0, 0.29); padding:10px; border-radius:5px;" >Id Expediente:  <?php echo $id?></h5>
                <p class="card-text">
                       ID Paciente: <?php echo $idp?>
                    <br>ID Enfermera: <?php echo $ide?>
                    <br>ID Doctor: <?php echo $idd?>
                    <br>Peso: <?php echo $peso?>
                    <br>Talla: <?php echo $talla?>
                    <br>Estatura: <?php echo $estatura?>
                    <br>Alergias: <?php echo $alergias?>
                    <br>Temperatura: <?php echo $temperatura?>
                    </p>
                    <a href="html/doctor/info-exp.php?exp=<?php echo $id;?>" class="btn btn-info">Ver información completa del expediente</a> <br><br> 
                    <a href="html/doctor/info-pac.php?pac=<?php echo $idp;?>" class="btn btn-success">Ver información personal del paciente</a><br><br>
                    
            </div>
        </div>
        <?php

        

        }



        ?>
    </div>
</div><br> <br>




