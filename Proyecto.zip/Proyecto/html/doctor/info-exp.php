<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>información</title>
    <link rel="stylesheet" href="../../vendor/bootstrap/css/bootstrap.min.css">
</head>
<body>
    <br><div class="container">
    <div class="row">
        <?php
            include("../conexion.php");
            $con=conectar();

       
        $consulta = 'SELECT * FROM Expediente';
        $resultado = mysqli_query( $con, $consulta ) or die ( "Algo ha ido mal en la consulta a la base de datos");

         while ($columna = mysqli_fetch_array( $resultado ))
        {
            if($columna['idExpediente']==$_GET['exp']){
             $id=$columna['idExpediente'];
             $peso=$columna['peso'];
             $talla=$columna['talla'];
             $estatura=$columna['estatura'];
             $temperatura=$columna['temperatura'];
             $alergias=$columna['alergias'];
             $ide=$columna['Enfermera_idEnfermera'];
             $idd=$columna['Doctor_idDoctor'];
             $idp=$columna['Paciente_idPaciente'];
             $nota=$columna['nota_medica'];
             $estudios=$columna['estudios'];
             $receta=$columna['receta'];
            }
        }
        

        
             ?>
        <div class="card" style="width: 90%; ">
            <div class="card-body">
                <h5 class="card-title" style="background-color:rgba(0, 0, 0, 0.29); padding:10px; border-radius:5px;" >Id Expediente:  <?php echo $id?></h5>
                <p class="card-text">
                       ID Paciente: <?php echo $idp?>
                    <br>ID Enfermera: <?php echo $ide?>
                    <br>ID Doctor: <?php echo $idd?>
                    <br>Peso: <?php echo $peso?>
                    <br>Talla: <?php echo $talla?>
                    <br>Estatura: <?php echo $estatura?>
                    <br>Alergias: <?php echo $alergias?>
                    <br>Temperatura: <?php echo $temperatura?>
                    <br>Notas: <?php echo $nota?>
                    <br>Estudios: <?php echo $estudios?>
                    <br>Receta: <?php echo $receta?>
                    </p>
                     
                    
                    <a href="javascript:window.history.go(-1);" class="btn btn-primary">Regresar</a>
                    <a href="receta.php?exp=<?php echo $id; ?>" class="btn btn-info">Generar Receta</a>
            </div>
        </div>
        <?php

        

        



        ?>
    </div>
</div><br> <br>





</body>
</html>