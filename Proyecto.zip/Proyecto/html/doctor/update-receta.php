<?php
  session_start();
    include("../conexion.php");
    $con=conectar();
    $receta=$_POST['receta'];
    $nota=$_POST['nota'];
    $id=$_POST['id'];
    $idd=$_SESSION['ide'];

    mysqli_query($con,"UPDATE Expediente SET receta = '$receta' WHERE idExpediente='$id'");
    mysqli_query($con,"UPDATE Expediente SET nota_medica = '$nota' WHERE idExpediente='$id'");
    mysqli_query($con,"UPDATE Expediente SET Doctor_idDoctor = '$idd' WHERE idExpediente='$id'");
                 
      
      
  
  header("Location: ../../index.php");
  exit();
?>