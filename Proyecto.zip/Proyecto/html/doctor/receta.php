<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Generar Receta</title>
    <link rel="stylesheet" href="../../vendor/bootstrap/css/bootstrap.min.css">
</head>





<body class="container">
   <div class="row">
   
    <form action="update-receta.php" method="post" class="col">
       <h1 class="text-muted">Ingrese receta</h1>
        <div class="form-group">
            <label for="exampleInputEmail1">Nota del Medico:</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Descripcion breve de los sintomas" name="nota" required >
            <label for="exampleInputEmail1">Receta:</label>
            <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Ingrese medicamentos que son necesarios para el paciente" name="receta" required >
            <input type="hidden" name="id" value="<?php echo $_GET['exp']; ?>">
            
            
            
        </div>
        <button type="submit" class="btn btn-primary">Generar</button><br><br>
       
    </form>
    </div>
</body>
</html>