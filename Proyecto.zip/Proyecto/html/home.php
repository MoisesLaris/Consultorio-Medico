<header class="masthead text-center text-white">
    <div class="masthead-content">
      <div class="container">
        <h1 class="masthead-heading mb-0">Clinica Medica</h1>
        <h2 class="masthead-subheading mb-0"></h2>
        <a href="#!awards" class="btn btn-primary btn-xl rounded-pill mt-5">Obten tu primer consulta aquí</a>
      </div>
    </div>
  </header>

  <section>
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6 order-lg-2">
          <div class="p-5">
            <img class="img-fluid rounded-circle" src="img/doc3.jpg" alt="">
          </div>
        </div>
        <div class="col-lg-6 order-lg-1">
          <div class="p-5">
            <h2 class="display-4">Consultas Online</h2>
            <p>Somos encargados de brindar consultas online a la gente con escasos recursos con la mas alta tecnología del mercado.</p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6">
          <div class="p-5">
            <img class="img-fluid rounded-circle" src="img/doc1.jpg" alt="">
          </div>
        </div>
        <div class="col-lg-6">
          <div class="p-5">
            <h2 class="display-4">Profecionistas Certificados</h2>
            <p>Contamos con los más experimentados Medicos y Enfermeras de todo el país. Puedes tener la seguridad de que no serás atendido una persona no certificada. Contamos con la validación de nuestros medicos y enfermerás ante el gobierno.</p>
            <a href="#!skaters">Visita nuestra galeria</a> 
          </div>
        </div>
      </div>
    </div>
  </section>

  <section>
    <div class="container">
      <div class="row align-items-center">
        <div class="col-lg-6 order-lg-2">
          <div class="p-5">
            <img class="img-fluid rounded-circle" src="img/nurse1.jpg" alt="">
          </div>
        </div>
        <div class="col-lg-6 order-lg-1">
          <div class="p-5">
            <h2 class="display-4">La mejor atención</h2>
            <p>Desde que producimos musica no tendras que preocuparte por tener que comprar musica o pagar caras suscripciones, descarga nuestra musica de manera gratuita y escuchala en nuestro sitio web. </p>
             <a href="#!music">Observa nuestros medicos</a>
             
          </div>
        </div>
      </div>
    </div>
   
  </section>