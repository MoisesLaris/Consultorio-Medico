
   <?php
    session_start();
    include("../html/conexion.php");
    $con=conectar();

        $correo=$_GET["correo"];
        
        echo $correo;    
        
        $consulta = 'SELECT * FROM Enfermera';
        $resultado = mysqli_query( $con, $consulta ) or die ( "Algo ha ido mal en la consulta a la base de datos");

        

?>