var app = angular.module('app', ['ngRoute']);
app.config(function ($routeProvider) {
    // configure the routes
    $routeProvider
        .when('/', {
            // route for the home page
            templateUrl: 'html/home.php',
            controller: 'homeController'
        })
        .when('/video', {
            // route for the about page
            templateUrl: 'https://3b851050.ngrok.io',
            controller: 'skaters'
        })
        .when('/consulta', {
            // route for the contact page
            templateUrl: 'html/enfermera/consulta.php',
            controller: 'consulta'
        })
        .when('/pacientes', {
            // route for the contact page
            templateUrl: 'html/doctor/pacientes.php',
            controller: 'consulta'
        })
        .when('/expedientes', {
            // route for the contact page
            templateUrl: 'html/doctor/expedientes.php',
            controller: 'consulta'
        })
        .when('/expedientes2', {
            // route for the contact page
            templateUrl: 'html/doctor/expedientes2.php',
            controller: 'consulta'
        })
        .when('/nuevo', {
            // route for the contact page
            templateUrl: 'html/enfermera/nuevo.php',
            controller: 'nuevo'
        })
        .when('/login', {
            // route for the contact page
            templateUrl: 'html/log.php',
            controller: 'login'
        })
        .otherwise({
            // when all else fails
            templateUrl: 'html/enfermera/error.php',
            controller: 'notFoundController'
        });

});



app.controller('homeController', function ($scope) {
    $scope.message = 'Welcome to my home page!';
});
app.controller('login', function ($scope) {
    //Cuestionario
    $scope.Preguntas = [
        {
            id: 1,
            pregunta: 'Nombre de las dos extremidades de una patineta:',
            correcta: 1,
            respuestaUsuario: null,
            user: null,
            respuestas: [

                {
                    id: 1,
                    text: 'Tail y Nose'
                },
                {
                    id: 2,
                    text: 'Trucks'
                },
                {
                    id: 3,
                    text: 'Llantas'
                },
                {
                    id: 4,
                    text: 'Madera'
                }

                ]
            },
        {
            id: 2,
            pregunta: 'Nombre de los soportes de la tabla y las llantas:',
            correcta: 2,
            respuestaUsuario: null,
            user: null,
            respuestas: [

                {
                    id: 1,
                    text: 'Soportes'
                },
                {
                    id: 2,
                    text: 'Trucks'
                },
                {
                    id: 3,
                    text: 'Baleros'
                },
                {
                    id: 4,
                    text: 'Ollie'
                }

                ]
            },
        {
            id: 3,
            pregunta: 'Cómo se llama el deporte que se hace con una patineta?',
            correcta: 3,
            respuestaUsuario: null,
            user: null,
            respuestas: [

                {
                    id: 1,
                    text: 'Long Board'
                },
                {
                    id: 2,
                    text: 'Jumping'
                },
                {
                    id: 3,
                    text: 'Skateboarding'
                },
                {
                    id: 4,
                    text: 'No existe tal cosa'
                }

                ]
            },
        {
            id: 4,
            pregunta: 'Qué significa sk8?',
            correcta: 1,
            respuestaUsuario: null,
            user: null,
            respuestas: [

                {
                    id: 1,
                    text: 'Skate'
                },
                {
                    id: 2,
                    text: 'Board'
                },
                {
                    id: 3,
                    text: 'Music'
                },
                {
                    id: 4,
                    text: 'Ninguna de las anteriores'
                }

                ]
            },
        {
            id: 5,
            pregunta: 'Persona mas joven en ganar los XGames de skateboard:',
            correcta: 4,
            respuestaUsuario: null,
            user: null,
            respuestas: [

                {
                    id: 1,
                    text: 'Tony Hawk'
                },
                {
                    id: 2,
                    text: 'Nyjah Houston'
                },
                {
                    id: 3,
                    text: 'Paul Rodriguez'
                },
                {
                    id: 4,
                    text: 'Ryan Sheckler'
                }

                ]
            },
        {
            id: 6,
            pregunta: 'Por qué se le denomina musica "indie"?',
            correcta: 3,
            respuestaUsuario: null,
            user: null,
            respuestas: [

                {
                    id: 1,
                    text: 'Alternativo'
                },
                {
                    id: 2,
                    text: 'De los pueblos indios'
                },
                {
                    id: 3,
                    text: 'Independiente'
                },
                {
                    id: 4,
                    text: 'Musica Hipster'
                }

                ]
            },
        {
            id: 7,
            pregunta: 'Cual de estas marcas no hace tablas para patinar en la actualidad?',
            correcta: 1,
            respuestaUsuario: null,
            user: null,
            respuestas: [

                {
                    id: 1,
                    text: 'Vans'
                },
                {
                    id: 2,
                    text: 'Element'
                },
                {
                    id: 3,
                    text: 'Plan b'
                },
                {
                    id: 4,
                    text: 'Enjoy'
                }

                ]
            }

        ];
    $scope.contadorC = 0;
    $scope.contadorM = 0;
    $scope.calificacion = 0;
    $scope.validar = function () {
        $scope.contadorC = 0;
        $scope.contadorM = 0;

        for (var i = 0; i < $scope.Preguntas.length; i++) {
            if ($scope.Preguntas[i].respuestaUsuario == null) {
                $scope.contadorC = 0;
                $scope.contadorM = 0;
                for (var j = 0; i < $scope.Preguntas.length; j++)
                    $scope.Preguntas[j].user = null;
                break;
            } else {
                if ($scope.Preguntas[i].correcta == $scope.Preguntas[i].respuestaUsuario) {
                    $scope.Preguntas[i].user = true;
                    $scope.contadorC++;
                } else {
                    $scope.Preguntas[i].user = false;
                    $scope.contadorM++;
                }
            }
        }
        $scope.calificacion = ($scope.contadorC / $scope.Preguntas.length) * 100;
    }
});
app.controller('consulta', function ($scope) {
   $scope.hola='quiubo';
});
app.controller('music', function ($scope) {

    $scope.musica = [
        {
            titulo: 'Capuccino City',
            artista: 'Rolling Blackouts Coastal Fever',
            portada: 'img/a5.jpg',
            ruta: 'mp3/1.mp3'

            },
        {
            titulo: 'Help Me Lose My Mind',
            artista: 'Disclosure',
            portada: 'img/a3.jpg',
            ruta: 'mp3/2.mp3'
            },
        {
            titulo: 'Harmony Hall',
            artista: 'Vampire Weekend',
            portada: 'img/a8.jpg',
            ruta: 'mp3/3.mp3'
            },
        {
            titulo: 'Nothing But Thieves',
            artista: 'Gods',
            portada: 'img/a7.jpg',
            ruta: 'mp3/4.mp3'
            },
        {
            titulo: 'Im not gettin sober, Im just getting older ',
            artista: 'Nancy',
            portada: 'img/a4.jpg',
            ruta: 'mp3/5.mp3'
            },
        {
            titulo: 'Gemini ',
            artista: 'The Belafontes',
            portada: 'img/a1.jpg',
            ruta: 'mp3/6.mp3'
            },
        {
            titulo: 'You Had Your with You',
            artista: 'The National',
            portada: 'img/a6.jpg',
            ruta: 'mp3/7.mp3'
            },


        ];


});
app.controller('notFoundController', function ($scope) {

    $scope.message = 'There seems to be a problem finding the page you wanted';
    //$scope.attemptedPath = $location.path();

});
